# Reference

- https://expressjs.com/en/guide/writing-middleware.html
- https://expressjs.com/en/guide/routing.html
- https://www.npmjs.com/package/dateformat
- https://www.tutorialspoint.com/nodejs/nodejs_request_object.htm